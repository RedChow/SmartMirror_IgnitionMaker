def getLineScore(tagPath):
	import urllib2
	import json
		
	logger = system.util.getLogger('nhlapi logger')
	tag_parts = tagPath.split('/')
	base_path = '/'.join(tag_parts[:-1])
	game_id = tag_parts[-2]
	
	url = system.tag.readBlocking([base_path + '/lineScoreLink'])[0].value
	r = urllib2.urlopen(url)
	html = r.read()
	game_data = json.loads(html)
	
	try:
		if not game_data['intermissionInfo']['inIntermission'] and game_data['currentPeriodTimeRemaining'].lower() == 'final':
			system.tag.writeBlocking([base_path + '/isGameOver'], [True])
	except:
		pass
	finally:
		new_json = {'{0}'.format(game_id): game_data}
		new_json_dumps = json.dumps(new_json)
		system.cirruslink.engine.publish('Chariot SCADA', 'nhl/games', new_json_dumps, 0, 0)

def setUpNHLGames():
	import json
	import urllib2
	import time
	from datetime import datetime, timedelta
	from java.util import Date
	from java.util import Calendar, GregorianCalendar
	
	t = datetime.today()
	days_before = 1
	days_after = 0
	t = datetime.today()
	times = [t + timedelta(days=i) for i in range(-days_before, days_after + 1)]
	time_strings = [x.strftime('%Y-%m-%d') for x in times]
	
	#Test times
	#time_strings = ['2019-01-01', '2019-01-02']
	
	def datetimeToJavaDate(value):
		cal = GregorianCalendar(value.year, value.month - 1, value.day, value.hour, value.minute, value.second)
		cal.set(Calendar.MILLISECOND, value.microsecond / 1000)
		return cal.getTimeInMillis()/1000
		
	def convert_datetime(dt):
		n = time.time()
		offset = datetime.fromtimestamp(n) - datetime.utcfromtimestamp(n)
		return dt + offset
	
	for time_string in time_strings:
		url = 'https://statsapi.web.nhl.com/api/v1/schedule?startDate=%s&endDate=%s' % (time_string, time_string)	
		r = urllib2.urlopen(url)
		html = r.read()
		schedule_data = json.loads(html)
		for date in schedule_data['dates']:
			for game in date['games']:
				new_json = {'{0}'.format(game['gamePk']):game}
				new_json_dumps = json.dumps(new_json)
				system.cirruslink.engine.publish('Chariot SCADA', 'nhl/games', new_json_dumps, 0, 0)
		
				baseTagPath = "[default]SmartMirror/nhl"
				typeId = "nhl"
				tagType = "UdtInstance"
				st = game['gameDate'].replace('T', ' ').replace('Z', '')
				st_dt = datetime.strptime(st, '%Y-%m-%d %H:%M:%S')
		
				utc = convert_datetime(st_dt)
				utc = datetimeToJavaDate(utc)
				tag = {"name": "%s" % game['gamePk'], "typeId": typeId, "tagType": tagType, "parameters":
					{'gameId': game['gamePk'],
					 'lineScoreLink': 'https://statsapi.web.nhl.com/api/v1/game/%s/linescore' % game['gamePk'],
					 'startTimeUTC': utc}}
				system.tag.configure(baseTagPath, [tag], 'o')
		

def getDisplayTime(game_id):
	from datetime import datetime
	import time
	
	def convert_datetime(dt):
		n = time.time()
		offset = datetime.fromtimestamp(n) - datetime.utcfromtimestamp(n)
		return dt + offset
	
	logger = system.util.getLogger('nhlapi logger: getDisplayTime')
	tags = ['[MQTT Engine]nhl/nhl/games/{0}/gameDate'.format(game_id), 
	'[MQTT Engine]nhl/nhl/games/{0}/currentPeriod'.format(game_id),
	'[MQTT Engine]nhl/nhl/games/{0}/currentPeriodOrdinal'.format(game_id),
	'[MQTT Engine]nhl/nhl/games/{0}/currentPeriodTimeRemaining'.format(game_id),
	'[MQTT Engine]nhl/nhl/games/{0}/intermissionInfo/inIntermission'.format(game_id),
	'[MQTT Engine]nhl/nhl/games/{0}/intermissionInfo/intermissionTimeRemaining'.format(game_id)]
	
	values = system.tag.readBlocking(tags)
	
	current_period = values[1].value
	if current_period is None:
		d = values[0].value
		dt_s = d.replace('T', ' ').replace('Z', '')
		dt = convert_datetime(datetime.strptime(dt_s, '%Y-%m-%d %H:%M:%S'))
		return dt.strftime('%Y-%m-%d %H:%M')
	
	in_intermission = values[4].value
	intermission_time_remaining = values[5].value
	if in_intermission:
		minutes = intermission_time_remaining/60
		seconds = intermission_time_remaining - 60*minutes
		minutes_str = '{0:02}'.format(minutes)
		seconds_str = '{0:02}'.format(seconds)
		return minutes_str + ':' + seconds_str
	
	current_period_ordinal = values[2].value
	current_period_remaining = values[3].value
	if current_period_ordinal is not None and current_period_remaining is not None:
		return current_period_ordinal + ' ' + current_period_remaining
		
	return ''
	
	
	
	





