def deleteNHLGameFiles():
	tags_to_delete = []
		
	tag_paths = ['[MQTT Engine]nhl/nhl/games', '[default]SmartMirror/nhl']
	for tag_path in tag_paths: 
		results = system.tag.browse(path = tag_path)
		for result in results.getResults():
			tags_to_delete.append('{0}'.format(result['fullPath']))
			
	system.tag.deleteTags(tags_to_delete)