def getWeather(tagPath):
	"""
	tagPath should contain all necessary values for getting weather data
	"""
	import json
	params = system.tag.getConfiguration(tagPath)
	logger = system.util.getLogger('weather logger')
	try:
		api = params[0]['parameters']['apikey'].value
		lat = params[0]['parameters']['latitude'].value
		long = params[0]['parameters']['longitude'].value
		mqtt_sub_name = params[0]['parameters']['mqttsubtopicname'].value
		#have to delete the alert path or else they will continually stack
		alert_path = '[MQTT Engine]weather/weather/' + mqtt_sub_name + '/alerts'
		system.tag.deleteTags([alert_path])
	except IndexError, KeyError:
		logger.error('error getting info')
		return
	else:
		client = system.net.httpClient()
		url = 'https://api.openweathermap.org/data/2.5/onecall?lat={0}&lon={1}&appid={2}&units=metric'
		url = url.format(lat, long, api)
		r = client.get(url)
		json_dumps = json.dumps(r.json)
		system.cirruslink.engine.publish('Chariot SCADA', 'weather/' + mqtt_sub_name, json_dumps, 0, 0)